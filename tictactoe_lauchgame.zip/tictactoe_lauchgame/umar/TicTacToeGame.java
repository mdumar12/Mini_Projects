package com.tictactoe_lauchgame.umar;

public class TicTacToeGame {
	static char board[][];
	
	//Constructor to initialize board
	public TicTacToeGame() {
		board=new char[3][3];
		initialBoard();
	}
	
	static void initialBoard() {
		for(int i=0;i<board.length;i++) {
			for(int j=0;j<board.length;j++) {
				board[i][j]=' ';
			}
		}
	}
	
	static void disBoard() {
		System.out.println("------------");
		for(int i=0;i<board.length;i++) {
			System.out.print("|");
			for(int j=0;j<board.length;j++) {
				System.out.print(board[i][j]+" | ");
			}
			System.out.println("\n------------");
		}
	}

	static void placeMark(int row,int col,char mark) {
		if( (row>=0 && row<board.length)  &&  (col>=0 && col<board.length) ) {
			board[row][col]=mark;
		}else {
			System.out.println("Invalid Input, Kindly enter valid Input in between 0 to 3 ");
		}
	}
	
	static boolean chkColWin() {
			//This is for diagonal win conditions.
			for(int i=0;i<board.length;i++) {
				if(  ( board[0][i]!=' ' ) && ( board[0][i] == board[1][i] ) && ( board[1][i] == board[2][i] ) ) {
					return true;
				}
			}
			return false;
	}

	static boolean chkRowWin() {
		for(int i=0;i<board.length;i++) {
			if( ( board[i][0]!=' ' ) && ( board[i][0]==board[i][1] ) && ( board[i][1]==board[i][2] ) ) {
				return true;
			}
		}
		return false;
	}

	static boolean chkDiagonalWin() {
		if( ( board[0][0] != ' ' ) 
				&& ( ( board[0][0]==board[1][1] ) && ( board[1][1]==board[2][2] ) ) 
				|| ( board[0][2] != ' ' ) && ( board[0][2]==board[1][1] ) && ( board[1][1]==board[2][0] ) ) {
			return true;
		}
		
		return false;
	}

	static boolean chkDraw() {
		for(int i=0;i<board.length;i++) {
			for(int j=0;j<board.length;j++) {
				if(board[i][j]==' ') {
					return false;
				}
			}
		}
		return true;
	}
}
