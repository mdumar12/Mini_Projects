package com.tictactoe_lauchgame.umar;

import java.util.Random;

public class AIPlayer extends Player{
	
	public AIPlayer(String name,char mark) {
		this.name=name;
		this.mark=mark;
	}
	
	void makeMove() {
		
		int row;
		int col;
		do {
			Random r=new Random();
			row=r.nextInt(3);
			col=r.nextInt(3);
		}while(!isValidMove(row, col));
		
		TicTacToeGame.placeMark(row, col, mark);
	}
}