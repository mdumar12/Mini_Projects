package com.tictactoe_lauchgame.umar;

//import java.util.Scanner;

public class LaunchTicTacGame {
	@SuppressWarnings({ "unused" })
	public static void main(String[] args) {
		TicTacToeGame t=new TicTacToeGame();
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter '1' to play with friend\nEnter '2' to play with AI :");
//		int choice=sc.nextInt();
//		HumanPlayer p1 = null,p2 = null;
//		switch (choice) {
//		case 1:
//			System.out.println("Greate, you have choose to play with friend..");
//			int twoPlayers=0;
//			while(twoPlayers<2) {
//				System.out.println("Enter the name :");
//				String name=sc.nextLine();
//				System.out.println("Enter a letter for identification : ");
//				char ch=sc.next().charAt(0);
//				if(twoPlayers==0) {
//					p1=new HumanPlayer(name, ch);
//				}else if(twoPlayers==1){
//					p2=new HumanPlayer(name, ch);
//				}
//				twoPlayers++;
//			}
//			break;
//		case 2:
//			System.out.println("Greate, you have choose to play with AI..");
//			break;
//		default :
//			System.out.println("Kindly enter valid one as to go ahead..");
//			break;
//		}
		HumanPlayer p1=new HumanPlayer("umar"+"'s", 'X');
		AIPlayer p2=new AIPlayer("noor"+"'s", 'O');
		
		Player cp=p1;
		
		//Winning Conditions 
		while(true) {
			System.out.println(cp.name + " turn :");
			cp.makeMove();
			TicTacToeGame.disBoard();
			if( TicTacToeGame.chkColWin() 
					|| TicTacToeGame.chkRowWin() 
					|| TicTacToeGame.chkDiagonalWin() ) {
				System.out.println("Hurray!!!, "+cp.name+" "+"has won.");
				break;
			}else if(TicTacToeGame.chkDraw()){
				System.out.println("Game Draw...");
				break;
			}else {
				if(cp==p1) {
					cp=p2;
				}else {
					cp=p1;
				}
			}
		}
	}
}
